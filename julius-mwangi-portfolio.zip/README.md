# Julius Mwangi Kamau — Portfolio

This is a simple, responsive personal portfolio website.

## Publish free with GitHub Pages
1. Create a GitHub account.
2. Create a new public repository named `juliusmwangi.github.io` (or another repository).
3. Upload `index.html`.
4. Open Settings → Pages.
5. Select deployment from the `main` branch.
6. GitHub will provide your public portfolio URL.

Before publishing, review the personal details and edit anything you want to change.
